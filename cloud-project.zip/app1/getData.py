import boto3
from boto3.dynamodb.conditions import And, Attr

client = boto3.resource('dynamodb',aws_access_key_id='AKIAQUFZQ62BGKWCJPL4', aws_secret_access_key='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', region_name='us-east-1')
table = client.Table('table')

def collectData(category):
    response = table.scan(FilterExpression=Attr("cat").eq(category))
    data = response['Items']
    while 'LastEvaluatedKey' in response:
        response = table.scan(ExclusiveStartKey=response['LastEvaluatedKey'])
        data.extend(response['Items'])
        
    return data
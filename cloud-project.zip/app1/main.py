import json
from math import floor, ceil
import getData
import time
from http.server import BaseHTTPRequestHandler, HTTPServer
from html.parser import HTMLParser
from urllib.parse import urlparse, parse_qs

hostName = "0.0.0.0"
serverPort = 5000


def get_most_similar(query):
    try:
        now = time.time()
        # print('event:', json.dumps(event))
        # print('queryStringParameters:', str(json.dumps(event['queryStringParameters']['name'])))

        # print(event.get("body")["name"])
        # given string
        # s1 = event.get("body")["name"]
        # print(s1)
        print(query)
        parsed_query = parse_qs(query, keep_blank_values=False, strict_parsing=False, encoding='utf-8', errors='replace', max_num_fields=None, separator='&')
        s1 = parsed_query['name'][0]
        category = parsed_query['cat'][0]
        db_strings = getData.collectData(category)
        # jsons = json.loads(event["body"])

        # s1 = jsons["name"]

        # database string array
        # db_strings = ["TRAC", "TRACE", "RACTE", "CARTE"]
        max_similarity = {"point": 0, "string": ""}

        for i in range(len(db_strings)):
            s2 = db_strings[i]["text"]
            # If the s are equal
            if (s1 == s2):
                print(1.0)

            # Length of two s
            len1 = len(s1)
            len2 = len(s2)

            # Maximum distance upto which matching
            # is allowed
            max_dist = floor(max(len1, len2) / 2) - 1

            # Count of matches
            match = 0

            # Hash for matches
            hash_s1 = [0] * len(s1)
            hash_s2 = [0] * len(s2)

            # Traverse through the first
            for i in range(len1):

                # Check if there is any matches
                for j in range(max(0, i - max_dist),
                               min(len2, i + max_dist + 1)):

                    # If there is a match
                    if (s1[i] == s2[j] and hash_s2[j] == 0):
                        hash_s1[i] = 1
                        hash_s2[j] = 1
                        match += 1
                        break
            # print(s1, s2)
            # print(match)
            # If there is no match
            if (match == 0):
                max_similarity = {
                    "point": match,
                    "string": s2,
                    # "event": event
                    # "event": json.dumps(event.get("body").get("name"))
                }
                continue

            # Number of transpositions
            t = 0
            point = 0

            # Count number of occurrences
            # where two characters match but
            # there is a third matched character
            # in between the indices
            for i in range(len1):
                if (hash_s1[i]):

                    # Find the next matched character
                    # in second
                    while (hash_s2[point] == 0):
                        point += 1

                    if (s1[i] != s2[point]):
                        t += 1
                    point += 1
            t = t//2

            # Return the Jaro Similarity
            result = (match / len1 + match / len2 +
                      (match - t) / match) / 3.0
            if result > max_similarity["point"]:
                max_similarity = {
                    "point": result,
                    "string": s2,
                    # "event": event
                    # "event": json.dumps(event.get("body").get("name"))
                }

        done = time.time()
        print((done - now) * 1000,
              {'statusCode': 200,
               'body': json.dumps(max_similarity)}
              )

        return {"duration": str(done - now), "data":max_similarity}

    except Exception as e:
        print(e)
        max_similarity = {
            "point": 0.4,
            "string": str("json.dumps(event['queryStringParameters']['name'])"),
            # "event": event
            # "event": json.dumps(event.get("body").get("name"))
        }


class MyServer(BaseHTTPRequestHandler):

    def do_GET(self):
        req = urlparse("http://asd.com" + self.path)
        print(req)
        resp = json.dumps(get_most_similar(req.query))
        self.send_response(200)
        self.send_header('Content-type', 'application/text')
        self.end_headers()
        self.wfile.write(bytes(resp, "UTF-8"))


if __name__ == "__main__":
    webServer = HTTPServer((hostName, serverPort), MyServer)
    print("Server started http://%s:%s" % (hostName, serverPort))

    try:
        webServer.serve_forever()
    except KeyboardInterrupt:
        pass

    webServer.server_close()
    print("Server stopped.")
